package com.example.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.net.Uri;
import android.speech.tts.Voice;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

public class MainActivity extends Activity {
    private static final int REQ_MIC = 10, REQ_CAMERA = 11, REQ_PERMS = 12;
    private LinearLayout chat;
    private ScrollView scroll;
    private EditText prompt, keyInput;
    private TextView status;
    private Button sendButton;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Bitmap pendingImage;
    private boolean speakReplies = true;
    private String activeAssistant = "JARVIS";
    private TextView assistantLabel;
    private final String PREFS = "assistant_memory_v1";

    private int cyan = Color.rgb(74, 226, 245);
    private int bg = Color.rgb(4, 15, 27);
    private int panel = Color.rgb(10, 31, 48);

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildUi();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) { tts.setLanguage(Locale.US); selectVoiceForAssistant(); }
        });
        addMessage("JARVIS", "Systems online. I am ready, Sir. Enter your Gemini API key to connect the AI brain.", false);
        selectVoiceForAssistant();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA}, REQ_PERMS);
        }
    }

    private void buildUi() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(18), dp(12), dp(18), dp(10));
        outer.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(2, 10, 22), Color.rgb(4, 22, 38), Color.rgb(1, 7, 17)}));
        setContentView(outer);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView brand = new TextView(this);
        brand.setText("J.A.R.V.I.S");
        brand.setTextColor(cyan);
        brand.setTextSize(23);
        brand.setLetterSpacing(0.20f);
        brand.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(42), 1));
        TextView version = new TextView(this);
        version.setText("AI SYSTEM  //  v1.0");
        version.setTextColor(Color.rgb(89, 160, 183));
        version.setTextSize(9);
        version.setLetterSpacing(0.12f);
        top.addView(version);
        outer.addView(top);

        View line = new View(this);
        line.setBackgroundColor(Color.rgb(23, 92, 117));
        LinearLayout.LayoutParams lineP = new LinearLayout.LayoutParams(-1, dp(1));
        lineP.bottomMargin = dp(8);
        outer.addView(line, lineP);

        status = new TextView(this);
        status.setText("● SYSTEM STANDBY  /  API KEY REQUIRED");
        status.setTextColor(Color.rgb(255, 190, 90));
        status.setTextSize(10);
        status.setLetterSpacing(0.10f);
        status.setGravity(Gravity.CENTER);
        outer.addView(status, new LinearLayout.LayoutParams(-1, dp(25)));

        LinearLayout assistantSwitch = new LinearLayout(this);
        assistantSwitch.setOrientation(LinearLayout.HORIZONTAL);
        Button jarvisTab = button("JARVIS  ♂");
        Button novaTab = button("NOVA  ♀");
        jarvisTab.setOnClickListener(v -> switchAssistant("JARVIS"));
        novaTab.setOnClickListener(v -> switchAssistant("NOVA"));
        assistantSwitch.addView(jarvisTab, new LinearLayout.LayoutParams(0, dp(40), 1));
        LinearLayout.LayoutParams novaParams = new LinearLayout.LayoutParams(0, dp(40), 1);
        novaParams.leftMargin = dp(8);
        assistantSwitch.addView(novaTab, novaParams);
        LinearLayout.LayoutParams switchParams = new LinearLayout.LayoutParams(-1, dp(42));
        switchParams.bottomMargin = dp(5);
        outer.addView(assistantSwitch, switchParams);
        assistantLabel = new TextView(this);
        assistantLabel.setText("ACTIVE ASSISTANT: JARVIS");
        assistantLabel.setTextColor(cyan);
        assistantLabel.setTextSize(10);
        assistantLabel.setGravity(Gravity.CENTER);
        outer.addView(assistantLabel, new LinearLayout.LayoutParams(-1, dp(20)));

        ReactorView reactor = new ReactorView();
        LinearLayout.LayoutParams reactorP = new LinearLayout.LayoutParams(-1, dp(164));
        reactorP.topMargin = dp(2);
        outer.addView(reactor, reactorP);

        TextView coreLabel = new TextView(this);
        coreLabel.setText("ARC CORE  •  NEURAL INTERFACE");
        coreLabel.setTextColor(Color.rgb(99, 191, 211));
        coreLabel.setTextSize(9);
        coreLabel.setGravity(Gravity.CENTER);
        coreLabel.setLetterSpacing(0.16f);
        LinearLayout.LayoutParams coreP = new LinearLayout.LayoutParams(-1, dp(20));
        coreP.bottomMargin = dp(7);
        outer.addView(coreLabel, coreP);

        LinearLayout keyPanel = new LinearLayout(this);
        keyPanel.setOrientation(LinearLayout.HORIZONTAL);
        keyPanel.setGravity(Gravity.CENTER_VERTICAL);
        keyPanel.setPadding(dp(10), dp(2), dp(5), dp(2));
        keyPanel.setBackground(round(Color.rgb(8, 30, 46), 12));
        keyInput = new EditText(this);
        keyInput.setSingleLine(true);
        keyInput.setHint("Gemini API key");
        keyInput.setTextColor(Color.WHITE);
        keyInput.setHintTextColor(Color.rgb(105, 145, 160));
        keyInput.setTextSize(12);
        keyInput.setInputType(129);
        keyInput.setBackgroundColor(Color.TRANSPARENT);
        keyInput.setText(readSecret());
        keyPanel.addView(keyInput, new LinearLayout.LayoutParams(0, dp(43), 1));
        Button save = button("SAVE");
        save.setTextSize(10);
        keyPanel.addView(save, new LinearLayout.LayoutParams(dp(76), dp(38)));
        save.setOnClickListener(v -> {
            saveSecret(keyInput.getText().toString().trim());
            status.setText("● API KEY STORED SECURELY");
            status.setTextColor(cyan);
            hideKeyboard();
        });
        LinearLayout.LayoutParams keyP = new LinearLayout.LayoutParams(-1, dp(49));
        keyP.bottomMargin = dp(8);
        outer.addView(keyPanel, keyP);

        TextView feedTitle = new TextView(this);
        feedTitle.setText("  //  COMMUNICATION CHANNEL");
        feedTitle.setTextColor(Color.rgb(81, 177, 201));
        feedTitle.setTextSize(9);
        feedTitle.setLetterSpacing(0.12f);
        outer.addView(feedTitle, new LinearLayout.LayoutParams(-1, dp(20)));

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        chat = new LinearLayout(this);
        chat.setOrientation(LinearLayout.VERTICAL);
        chat.setPadding(dp(2), dp(5), dp(2), dp(5));
        scroll.addView(chat);
        LinearLayout.LayoutParams chatParams = new LinearLayout.LayoutParams(-1, 0, 1);
        chatParams.setMargins(0, dp(2), 0, dp(7));
        outer.addView(scroll, chatParams);

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        Button voice = button("◉  VOICE");
        voice.setOnClickListener(v -> startVoice());
        Button camera = button("▣  SCAN IMAGE");
        camera.setOnClickListener(v -> takePhoto());
        tools.addView(voice, new LinearLayout.LayoutParams(0, dp(43), 1));
        LinearLayout.LayoutParams cameraP = new LinearLayout.LayoutParams(0, dp(43), 1);
        cameraP.leftMargin = dp(8);
        tools.addView(camera, cameraP);
        outer.addView(tools);

        prompt = new EditText(this);
        prompt.setHint("Talk to " + activeAssistant + "...");
        prompt.setTextColor(Color.WHITE);
        prompt.setHintTextColor(Color.rgb(105, 145, 160));
        prompt.setTextSize(14);
        prompt.setMinLines(1);
        prompt.setMaxLines(3);
        prompt.setPadding(dp(14), dp(10), dp(14), dp(10));
        prompt.setBackground(round(Color.rgb(8, 30, 46), 12));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, -2);
        inputParams.setMargins(0, dp(8), 0, dp(8));
        outer.addView(prompt, inputParams);

        sendButton = button("⟶  EXECUTE COMMAND");
        sendButton.setOnClickListener(v -> sendPrompt());
        outer.addView(sendButton, new LinearLayout.LayoutParams(-1, dp(48)));

        TextView footer = new TextView(this);
        footer.setText("SECURE LOCAL KEY STORAGE   •   GEMINI AI LINK");
        footer.setTextColor(Color.rgb(63, 119, 139));
        footer.setTextSize(8);
        footer.setLetterSpacing(0.10f);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerP = new LinearLayout.LayoutParams(-1, dp(21));
        footerP.topMargin = dp(4);
        outer.addView(footer, footerP);
    }

    private class ReactorView extends View {
        private final android.graphics.Paint paint = new android.graphics.Paint(3);
        private final android.graphics.RectF oval = new android.graphics.RectF();
        private float rotation = 0f;
        ReactorView() { super(MainActivity.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(android.graphics.Canvas c) {
            super.onDraw(c);
            float cx = getWidth()/2f, cy = getHeight()/2f;
            float radius = Math.min(getWidth(), getHeight()) * 0.37f;
            paint.setStyle(android.graphics.Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1));
            paint.setColor(Color.rgb(16, 94, 126));
            c.drawCircle(cx, cy, radius+dp(17), paint);
            paint.setColor(Color.rgb(22, 145, 174));
            paint.setStrokeWidth(dp(2));
            c.drawCircle(cx, cy, radius+dp(8), paint);
            paint.setColor(Color.rgb(34, 199, 224));
            paint.setStrokeWidth(dp(3));
            oval.set(cx-radius, cy-radius, cx+radius, cy+radius);
            c.drawArc(oval, rotation, 112, false, paint);
            c.drawArc(oval, rotation+180, 72, false, paint);
            paint.setStrokeWidth(dp(1));
            paint.setColor(Color.rgb(38, 112, 143));
            c.drawCircle(cx, cy, radius-dp(8), paint);
            paint.setStyle(android.graphics.Paint.Style.FILL);
            paint.setColor(Color.rgb(8, 44, 65));
            c.drawCircle(cx, cy, radius-dp(14), paint);
            paint.setColor(Color.rgb(76, 226, 245));
            paint.setShadowLayer(dp(18), 0, 0, Color.rgb(0, 190, 255));
            c.drawCircle(cx, cy, dp(5), paint);
            paint.clearShadowLayer();
            paint.setColor(Color.rgb(142, 242, 255));
            paint.setTextAlign(android.graphics.Paint.Align.CENTER);
            paint.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
            paint.setTextSize(dp(17));
            c.drawText("J", cx, cy+dp(34), paint);
            paint.setTextSize(dp(7));
            paint.setColor(Color.rgb(79, 181, 204));
            c.drawText("NEURAL CORE", cx, cy+dp(49), paint);
            rotation = (rotation + 1.1f) % 360f;
            postInvalidateDelayed(35);
        }
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.rgb(2,18,29)); b.setTextSize(11); b.setLetterSpacing(0.06f);
        b.setTypeface(Typeface.DEFAULT_BOLD); b.setAllCaps(false);
        b.setBackground(round(cyan, 10));
        return b;
    }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private void hideKeyboard() {
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(prompt.getWindowToken(),0);
    }
    private void addMessage(String who, String text, boolean user) {
        TextView bubble = new TextView(this);
        String speaker = user ? "YOU  //  TRANSMISSION" : who + "  //  RESPONSE";
        bubble.setText(speaker + "\n" + text);
        bubble.setTextColor(user ? Color.rgb(206, 246, 255) : Color.rgb(220, 241, 248));
        bubble.setTextSize(13);
        bubble.setLineSpacing(dp(2), 1.0f);
        bubble.setPadding(dp(13),dp(11),dp(13),dp(11));
        bubble.setBackground(round(user ? Color.rgb(9, 53, 72) : Color.rgb(9, 34, 49), 13));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,dp(5),0,dp(5));
        chat.addView(bubble,p);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void switchAssistant(String name) {
        activeAssistant = name;
        if (assistantLabel != null) assistantLabel.setText("ACTIVE ASSISTANT: " + name);
        if (prompt != null) prompt.setHint("Talk to " + name + "...");
        selectVoiceForAssistant();
        String greeting = name.equals("JARVIS")
                ? "JARVIS is online, Sir. How may I assist you?"
                : "Hi! NOVA is here. What would you like to do?";
        addMessage(name, greeting, false);
        if (tts != null) tts.speak(greeting, TextToSpeech.QUEUE_FLUSH, null, "assistant_switch");
    }

    private void selectVoiceForAssistant() {
        if (tts == null) return;
        try {
            java.util.Set<Voice> voices = tts.getVoices();
            if (voices == null) return;
            String wanted = activeAssistant.equals("NOVA") ? "female" : "male";
            Voice selected = null;
            for (Voice voice : voices) {
                String n = voice.getName().toLowerCase(Locale.ROOT);
                Locale l = voice.getLocale();
                if (l != null && l.getLanguage().equals("en") && (wanted.equals("female") ? (n.contains("female") || n.contains("woman")) : (n.contains("male") && !n.contains("female")))) {
                    selected = voice;
                    if (!voice.isNetworkConnectionRequired()) break;
                }
            }
            if (selected != null) tts.setVoice(selected);
            else tts.setLanguage(Locale.US); // Device TTS may not expose gender-labelled voices.
        } catch (Exception ignored) { }
    }

    private String memoryKey() { return activeAssistant.equals("NOVA") ? "nova_history" : "jarvis_history"; }

    private JSONArray getMemory() {
        try { return new JSONArray(getSharedPreferences(PREFS, MODE_PRIVATE).getString(memoryKey(), "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private void saveMemoryTurn(String userText, String assistantText) {
        try {
            JSONArray history = getMemory();
            history.put(new JSONObject().put("role", "user").put("text", userText));
            history.put(new JSONObject().put("role", "model").put("text", assistantText));
            while (history.length() > 24) {
                JSONArray trimmed = new JSONArray();
                for (int i = 2; i < history.length(); i++) trimmed.put(history.get(i));
                history = trimmed;
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(memoryKey(), history.toString()).apply();
        } catch (Exception ignored) { }
    }

    private boolean handleLocalCommand(String text) {
        String q = text.toLowerCase(Locale.ROOT).trim();
        if (q.contains("switch to jarvis") || q.equals("jarvis")) { switchAssistant("JARVIS"); return true; }
        if (q.contains("switch to nova") || q.equals("nova")) { switchAssistant("NOVA"); return true; }
        try {
            if (q.equals("open settings") || q.contains("phone settings")) {
                startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
                addMessage(activeAssistant, "Opening Android Settings.", false); return true;
            }
            if (q.contains("open wifi") || q.contains("wifi settings")) {
                startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS));
                addMessage(activeAssistant, "Opening Wi-Fi settings. You can change the setting there.", false); return true;
            }
            if (q.contains("open bluetooth") || q.contains("bluetooth settings")) {
                startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS));
                addMessage(activeAssistant, "Opening Bluetooth settings.", false); return true;
            }
            if (q.contains("open camera")) {
                startActivity(new Intent("android.media.action.IMAGE_CAPTURE"));
                addMessage(activeAssistant, "Opening the camera.", false); return true;
            }
            if (q.contains("open youtube")) {
                Intent launch = getPackageManager().getLaunchIntentForPackage("com.google.android.youtube");
                if (launch != null) startActivity(launch);
                else startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")));
                addMessage(activeAssistant, "Opening YouTube.", false); return true;
            }
            if (q.contains("open whatsapp")) {
                Intent launch = getPackageManager().getLaunchIntentForPackage("com.whatsapp");
                if (launch == null) launch = getPackageManager().getLaunchIntentForPackage("com.whatsapp.w4b");
                if (launch != null) startActivity(launch); else throw new Exception("WhatsApp is not installed.");
                addMessage(activeAssistant, "Opening WhatsApp.", false); return true;
            }
            if (q.startsWith("search for ")) {
                String term = text.substring(11).trim();
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(term))));
                addMessage(activeAssistant, "Searching the web for: " + term, false); return true;
            }
            if (q.startsWith("dial ")) {
                String number = text.substring(5).trim();
                startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))));
                addMessage(activeAssistant, "Opened the dialler. Review the number and tap Call yourself.", false); return true;
            }
        } catch (Exception e) {
            addMessage(activeAssistant, "I couldn't open that feature: " + e.getMessage(), false); return true;
        }
        return false;
    }

    private void sendPrompt() {
        String text = prompt.getText().toString().trim();
        if (text.isEmpty() && pendingImage == null) return;
        if (handleLocalCommand(text)) { prompt.setText(""); return; }
        String key = readSecret();
        if (key.isEmpty()) { addMessage(activeAssistant, "Please enter and save your Gemini API key first.", false); return; }
        prompt.setText(""); hideKeyboard();
        final String assistant = activeAssistant;
        final String userText = text.isEmpty() ? "Please analyse the attached image." : text;
        addMessage("YOU", userText + (pendingImage != null ? "\n[Image attached]" : ""), true);
        final Bitmap image = pendingImage; pendingImage = null;
        sendButton.setEnabled(false); status.setText("● " + assistant + " THINKING...");
        executor.execute(() -> {
            try {
                String answer = callGemini(key, userText, image, assistant);
                runOnUiThread(() -> {
                    // Store each assistant's conversation separately, even after switching.
                    String previous = activeAssistant;
                    activeAssistant = assistant;
                    saveMemoryTurn(userText, answer);
                    activeAssistant = previous;
                    addMessage(assistant, answer, false);
                    status.setText("● ONLINE"); sendButton.setEnabled(true);
                    if (speakReplies && tts != null) {
                        String previousAssistant = activeAssistant;
                        activeAssistant = assistant;
                        selectVoiceForAssistant();
                        tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, assistant.toLowerCase(Locale.ROOT) + "_reply");
                        activeAssistant = previousAssistant;
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> { addMessage(assistant, "Request failed: " + e.getMessage(), false); status.setText("● CONNECTION ERROR"); sendButton.setEnabled(true); });
            }
        });
    }

    private String callGemini(String key, String text, Bitmap image, String assistant) throws Exception {
        URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=" + key);
        HttpURLConnection c = (HttpURLConnection)url.openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(60000);
        c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json");
        JSONArray parts = new JSONArray().put(new JSONObject().put("text", text));
        if (image != null) {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            image.compress(Bitmap.CompressFormat.JPEG, 82, bytes);
            JSONObject inline = new JSONObject();
            inline.put("mimeType","image/jpeg"); inline.put("data", Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP));
            parts.put(new JSONObject().put("inlineData",inline));
        }
        JSONArray contents = new JSONArray();
        JSONArray history = new JSONArray(getSharedPreferences(PREFS, MODE_PRIVATE).getString(assistant.equals("NOVA") ? "nova_history" : "jarvis_history", "[]"));
        for (int i = Math.max(0, history.length() - 12); i < history.length(); i++) {
            JSONObject turn = history.getJSONObject(i);
            contents.put(new JSONObject().put("role", turn.optString("role", "user"))
                    .put("parts", new JSONArray().put(new JSONObject().put("text", turn.optString("text", "")))));
        }
        contents.put(new JSONObject().put("role", "user").put("parts", parts));
        JSONObject body = new JSONObject(); body.put("contents", contents);
        body.put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", personaInstructionFor(assistant)))));
        JSONObject config = new JSONObject(); config.put("temperature",0.8); config.put("maxOutputTokens",1200);
        body.put("generationConfig",config);
        try (OutputStream out = c.getOutputStream()) { out.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode();
        java.io.InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        java.io.ByteArrayOutputStream result = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[4096]; int n; while((n=stream.read(buf))!=-1) result.write(buf,0,n);
        String raw = result.toString("UTF-8"); c.disconnect();
        JSONObject response = new JSONObject(raw);
        if (code < 200 || code >= 300) {
            String msg = response.optJSONObject("error") != null ? response.getJSONObject("error").optString("message","Gemini API error") : "HTTP " + code;
            throw new Exception(msg);
        }
        JSONArray candidates = response.optJSONArray("candidates");
        if (candidates == null || candidates.length()==0) return "I couldn't create a response. Please try again.";
        return candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).optString("text","No text response.");
    }

    private String personaInstructionFor(String assistant) {
        return assistant.equals("NOVA")
                ? "You are NOVA, a warm, natural, human-like female personal assistant. Be friendly, emotionally intelligent, conversational and helpful. Speak English or Pakistani Urdu to match the user. Keep NOVA's memory separate from JARVIS."
                : "You are JARVIS, a composed, intelligent male personal assistant with a professional futuristic style. Address the user respectfully. Speak English or Pakistani Urdu to match the user. Keep JARVIS's memory separate from NOVA.";
    }

    private void startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { addMessage("JARVIS","Speech recognition is not available on this phone. You can type instead.",false); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_MIC); return;
        }
        try {
            if (recognizer != null) recognizer.destroy();
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new android.speech.RecognitionListener() {
                public void onReadyForSpeech(Bundle b){ status.setText("● LISTENING..."); }
                public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){}
                public void onEndOfSpeech(){status.setText("● PROCESSING VOICE...");}
                public void onError(int e){status.setText("● ONLINE");}
                public void onResults(Bundle b){
                    ArrayList<String> matches=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if(matches!=null&&!matches.isEmpty()){prompt.setText(matches.get(0));sendPrompt();}
                }
                public void onPartialResults(Bundle b){} public void onEvent(int t,Bundle b){}
            });
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-PK");
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-PK");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak to JARVIS");
            recognizer.startListening(i);
        } catch(Exception e){addMessage("JARVIS","Could not start voice input. Please type your message.",false);}
    }

    private void takePhoto() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA); return;
        }
        try { Intent i=new Intent("android.media.action.IMAGE_CAPTURE"); startActivityForResult(i,REQ_CAMERA); }
        catch(Exception e){addMessage("JARVIS","Camera app is unavailable.",false);}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_CAMERA && resultCode==RESULT_OK && data!=null && data.getExtras()!=null){
            Object obj=data.getExtras().get("data");
            if(obj instanceof Bitmap){pendingImage=(Bitmap)obj;addMessage("JARVIS","Photo attached. Type a question or press Send.",false);}
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if(requestCode==REQ_MIC && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) startVoice();
        if(requestCode==REQ_CAMERA && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) takePhoto();
    }

    // Encrypt the API key with an Android Keystore AES-GCM key before saving it.
    private SecretKey getSecretKey() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if(ks.containsAlias("jarvis_api_key")) return ((KeyStore.SecretKeyEntry)ks.getEntry("jarvis_api_key",null)).getSecretKey();
        KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder("jarvis_api_key",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return kg.generateKey();
    }
    private void saveSecret(String value) {
        try {
            if(value.isEmpty()) return;
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE,getSecretKey());
            byte[] encrypted=cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
            String stored=Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(encrypted,Base64.NO_WRAP);
            getSharedPreferences("jarvis_secure",MODE_PRIVATE).edit().putString("key",stored).apply();
        } catch(Exception e){addMessage("JARVIS","Could not securely save the API key.",false);}
    }
    private String readSecret() {
        try {
            String stored=getSharedPreferences("jarvis_secure",MODE_PRIVATE).getString("key","");
            if(stored.isEmpty()) return "";
            String[] p=stored.split(":"); Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE,getSecretKey(),new GCMParameterSpec(128,Base64.decode(p[0],Base64.NO_WRAP)));
            return new String(cipher.doFinal(Base64.decode(p[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);
        } catch(Exception e){return "";}
    }
    @Override protected void onDestroy() {
        if(recognizer!=null) recognizer.destroy();
        if(tts!=null) tts.shutdown();
        executor.shutdown();
        super.onDestroy();
    }
}
