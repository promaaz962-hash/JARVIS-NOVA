# JARVIS + NOVA — Dual Assistant Android Project

This project is an Android Studio starter app with two separate AI personas:

- **JARVIS** — male-coded, professional/technical assistant persona.
- **NOVA** — female-coded, friendly/conversational assistant persona.

Both use the same Gemini API key, but keep separate local conversation histories (`jarvis_history` and `nova_history`). Switching assistants does not merge their saved chat histories.

## Included in this build

- One-tap switching between JARVIS and NOVA.
- Voice command switching: say **“Switch to JARVIS”** or **“Switch to NOVA”** after pressing Voice.
- Gemini AI chat with a different system persona for each assistant.
- Separate local conversation memory for each assistant (last 6 pairs are sent as context; up to 12 pairs are retained locally).
- Android Text-to-Speech replies. The app attempts to select an English voice whose installed voice name indicates male/female. Actual voice gender and quality depend on the TTS engine and voices installed on the phone; Android does not guarantee a male or female voice.
- Speech recognition input, camera image capture, and image analysis.
- Basic safe Android actions: open Settings, Wi-Fi settings, Bluetooth settings, Camera, YouTube, WhatsApp, web search, and the phone dialler. Calls are not placed automatically; the user reviews and confirms in the dialler.
- Gemini API key encrypted with Android Keystore before local storage.
- GitHub Actions workflow to build a debug APK.

## Requirements

- Android 6.0 (API 23) or newer.
- Internet access and a Gemini API key.
- Microphone permission for voice input; camera permission is declared for camera-related functions.
- An Android speech-recognition service and installed Text-to-Speech voices.

## Build an APK with GitHub Actions

1. Extract the ZIP contents into the **root** of a new GitHub repository. Keep both the `JARVIS_ANDROID_APK_PROJECT` folder and the top-level `.github` folder.
2. Push the files to the repository's `main` branch, or open **Actions → Build JARVIS + NOVA Android APK → Run workflow**.
3. When the workflow completes, download the `JARVIS-NOVA-ANDROID-APK` artifact.
4. Extract `app-debug.apk` and install it on your Android phone. You may need to allow installation from that source.
5. Open the app, enter your Gemini API key, and tap **SAVE**.

## Phone-control and privacy limits

This is not unrestricted device control. Android protects sensitive operations. This starter app opens selected Android screens/apps and launches the dialler; it does not silently send messages, read all notifications, place calls, change every system setting, or control every app. More advanced accessibility-based automation would require a separate user-enabled Accessibility Service, careful disclosure, and additional testing. Sensitive actions should ask for confirmation.

Each assistant's conversation history is stored separately in the app's private local preferences. This is separation, not end-to-end encryption of chat history. The Gemini API key is encrypted with Android Keystore. A key embedded in a client app can still be exposed on a compromised/rooted device; a secure backend is preferable for a public release.

## Voice notes

The app uses the phone's installed Android Text-to-Speech engine. It attempts to choose a voice with a matching gender label in its voice name, but many devices do not expose gender labels. If the phone has no female or male English voice available, the default English voice may be used. Install additional voices in Android's Text-to-Speech settings if needed.

Speech recognition language support depends on the phone's recognition service. The starter currently requests English (Pakistan); Urdu recognition may require changing the recognition language or using a service that supports Urdu.

## Technical notes

- Package: `com.example.jarvis`
- Gemini model: `gemini-3.8-flash`
- Min SDK: 23
- Target SDK: 34
- This workflow creates a **debug APK**, not a signed Play Store release.
